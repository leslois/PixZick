Nous sommes actuellement entrain de faire l'adaptation sur android studio,
Nous avons pas pu terminer avant l'heure de la premi�re remise.
C'est pour cela qu'on vous pr�sente deux codes , mais qui sont compl�mentaires