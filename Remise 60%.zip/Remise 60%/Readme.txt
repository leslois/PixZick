Nous sommes actuellement entrain de faire l'adaptation sur android studio,
Nous avons pas pu terminer avant l'heure de la premi�re remise.
C'est pour cela qu'on vous pr�sente deux codes , mais qui sont compl�mentaires.

--- CONTENU DES DOSSIERS ---

Dans le dossier nomm� 'PixZick2V1' se  trouve notre application mobile avec toute l'iterface graphique.
Il y a la recuperation d'une image, et affichage de cette m�me image.

Dans le dossier 'SQLiteJDBCriverConnection' il y a l'IA demand� qui associe
� une image les couleurs moyennes et donc retrouve dans notre base de donn�es, 
nomm�e transverse.db, une musique la plus proche des couleurs et la luminosit� 
de l'image donn�e.