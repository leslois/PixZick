/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.sqlitejdbcriverconnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static net.sqlitejdbcriverconnection.Image.per_blue;
import static net.sqlitejdbcriverconnection.Image.per_green;
import static net.sqlitejdbcriverconnection.Image.per_red;

/**
 *
 * @author Thomas
 */
public class Recherche {
    
    private static double dif_red = 0;
    private static double dif_green = 0;
    private static double dif_blue = 0;
    
    private static double difference = 0;
    private static double cpt_difference = 1000;
    
    private static int ID = 0;
    
    private static String title;
    private static String auteur;
    private static String link;
    
    private static Connection connect() {
        // SQLite connection string
        String url = "jdbc:sqlite:C:/Users/Thomas/Documents/NetBeansProjects/SQLiteJDBCriverConnection/transverse.db";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
            System.out.println("Connection to SQLite has been established.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
    
    /**
     *
     * @throws IOException
     * @throws SQLException
     */
    public static void search() throws IOException, SQLException {
        String sql = "SELECT Id,rouge,vert,bleu FROM couleur";
        String sql_2 = "SELECT Id,titre,compositeur,lien FROM musique";
 
        try (Connection conn = Recherche.connect();
        Statement stmt = conn.createStatement();
        Statement stmt_2 = conn.createStatement();
        ResultSet rs    = stmt.executeQuery(sql);
        ResultSet rs_2    = stmt_2.executeQuery(sql_2)){
            
            
            
            while (rs.next()) {
                int num = rs.getInt("Id");
                
                double rouge = rs.getDouble("rouge");
                double vert = rs.getDouble("vert");
                double bleu = rs.getDouble("bleu");
                
                if (rouge < per_red)
                    dif_red = per_red - rouge;
                else 
                    dif_red = rouge - per_red;
                
                if (vert < per_green)
                    dif_green = per_green - vert;
                else 
                    dif_green = vert - per_green;
                
                if (bleu < per_blue)
                    dif_blue = per_blue - bleu;
                else 
                    dif_blue = bleu - per_blue;
                
                difference = dif_red + dif_green + dif_blue;
                
                if (difference < cpt_difference){
                    cpt_difference = difference;
                    ID = num;
                } 
            }

            System.out.println("ID: " + ID + "\nDifference/chemin : " + cpt_difference);           
            
            while (rs_2.next()) {
                int id_m = rs_2.getInt("Id");
                String nom = rs_2.getString("titre");
                String artiste = rs_2.getString("compositeur");
                String yt = rs_2.getString("lien");
                
                if (id_m == ID){
                    title = nom;
                    auteur = artiste;
                    link = yt;
                }                    
            }    
            System.out.println("\n\nID: " + ID + "\nTitre : " + title + "\nAuteur : " + auteur + "\nLien YT : " + link);
            
        } catch (SQLException e) {
            
            System.out.println(e.getMessage());
        }
    }
    
}
