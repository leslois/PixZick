/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.sqlitejdbcriverconnection;

import java.io.IOException;
import java.sql.SQLException;
import static net.sqlitejdbcriverconnection.Image.image;
import static net.sqlitejdbcriverconnection.Recherche.search;


/**
 *
 * @author Thomas
 */
public class Main {
    public static void main(String[] args) throws IOException, SQLException {
        image();
        search();
    }
}
