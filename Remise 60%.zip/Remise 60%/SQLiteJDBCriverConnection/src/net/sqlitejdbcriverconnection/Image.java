/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.sqlitejdbcriverconnection;

import java.util.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Thomas
 */
public class Image {
    
    private static String picture;
    
    private static double cpt_red = 0;
    public static double per_red = 0;
    
    private static  double cpt_blue = 0;
    public static  double per_blue = 0;
    
    private static double cpt_green = 0;
    public static double per_green = 0;
    
    private static double n = 0;
    
    public static void printPixelARGB(int pixel) {
        int alpha = (pixel >> 24) & 0xff;
        int red = (pixel >> 16) & 0xff;
        int green = (pixel >> 8) & 0xff;
        int blue = (pixel) & 0xff;
        cpt_red = red + cpt_red; 
        cpt_green = green + cpt_green;
        cpt_blue = blue + cpt_blue;
        //System.out.println("argb: " + alpha + ", " + red + ", " + green + ", " + blue);
      }

    private static void marchThroughImage(BufferedImage image) {
        int w = image.getWidth();
        int h = image.getHeight();
        System.out.println("width, height: " + w + ", " + h);

        for (int i = 0; i < h; i++) {
          for (int j = 0; j < w; j++) {
            //System.out.println("x,y: " + j + ", " + i);
            int pixel = image.getRGB(j, i);
            printPixelARGB(pixel);
            //System.out.println("");
          }
        }
        
        cpt_red = cpt_red/(w*h);
        cpt_green = cpt_green/(w*h);
        cpt_blue = cpt_blue/(w*h);
        
        n = cpt_red + cpt_green + cpt_blue;
        
        

        per_red = cpt_red * (100/n);
        per_green = 100*(cpt_green/n);
        per_blue = 100*(cpt_blue/n);
        
        per_red = Math.round(per_red);
        per_green = Math.round(per_green);
        per_blue = Math.round(per_blue);
      
        System.out.println("Red : " + per_red + "\nGreen : " + per_green + "\nBlue : " + per_blue);
    }

    /**
     *
     * @throws java.io.IOException
     */
    public static void image() throws IOException {
        // get the BufferedImage, using the ImageIO class
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Veuillez saisir le nom de l'image : ");
            picture = sc.nextLine();
            
            System.out.println("\n");
            
            BufferedImage image;
            image = ImageIO.read(new File(picture));
            marchThroughImage(image);
        }catch (IOException ex) {
            throw new RuntimeException("Image not yet implemented"); 
        }
                
    }
}
